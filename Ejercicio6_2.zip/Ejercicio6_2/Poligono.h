#ifndef POLIGONO_H_
#define POLIGONO_H_
#include "Coordenada.h"
#include <vector>
#include <iostream>
#include <math.h>
#include <bits/stdc++.h>
using namespace std;

class PoligonoIrreg{
	private:
		vector <Coordenada> v;
		vector <float> magnitudes;
	public:
		PoligonoIrreg();
		void anadeVertice(double c,double d);
		void imprimeVertices();
		double areaIrreg();
		void ordenaVert();
};
#endif
