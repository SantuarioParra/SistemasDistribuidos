#include "Poligono.h"
#include "Coordenada.h"
#include <iostream>
#include <vector>
#include <math.h>
#include <bits/stdc++.h>
using namespace std;

int main( )
{	
	float x,y,diff,r;	
	
	PoligonoIrreg poli1;
	for(int i=0;i<20;i++){
		x=((float)rand())/(float)RAND_MAX;
		y=((float)rand())/(float)RAND_MAX;
		x=x*(rand()%100-rand()%80)+rand()%80;
		y=y*(rand()%100-rand()%80)+rand()%80;
		if(rand()%2!=0){
			x=-x;
			y=-y;
		}		
		poli1.anadeVertice(x,y);
	}
	poli1.imprimeVertices();
	cout << "\n\n" << endl;	
	poli1.ordenaVert();
	poli1.imprimeVertices();
	
	return 0;
}
