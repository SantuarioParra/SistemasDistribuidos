#include "Poligono.h"
#include "Coordenada.h"
#include <iostream>
#include <vector>
#include <math.h>
#include <bits/stdc++.h>
using namespace std;


Coordenada::Coordenada(double xx, double yy) : x(xx), y(yy){}

double Coordenada::obtenerX(){
	return x;
}

double Coordenada::obtenerY(){
	return y;
}



PoligonoIrreg::PoligonoIrreg(){}

void PoligonoIrreg::anadeVertice(double a, double b){
	Coordenada aux(a,b);
	v.push_back(aux);
}

void PoligonoIrreg::imprimeVertices(){
	int i;
	double mag;
	//ordenaVert();
	for(i=0;i<v.size();i++){
		cout << "Coordenadas vértice " << i+1 << ": (" << v[i].obtenerX() << "," << v[i].obtenerY() << ")\n";
		mag=sqrt(pow(v[i].obtenerX(),2) + pow(v[i].obtenerY(),2));
	magnitudes.push_back(mag);
		cout << "Magnitud del vertice " << i+1 << ": " << mag << endl;
	}
}

void PoligonoIrreg::ordenaVert(){
	int i,j;
	vector<Coordenada> auxv=v;
	double det[v.size()][2], detaux[v.size()][2];
	for(i=0;i<v.size();i++){
		det[i][1]=sqrt(pow(v[i].obtenerX(),2) + pow(v[i].obtenerY(),2));
		det[i][2]=i;
	}
	for (i=0; i<v.size()-1; i++){
		for (j=i+1; j<v.size(); j++){
			if(det[i][1]>det[j][1]){
				detaux[i][1] = det[i][1];
				detaux[i][2] = det[i][2];
				det[i][1] = det[j][1];
				det[i][2] = det[j][2];
				det[j][1] = detaux[i][1];
				det[j][2] = detaux[i][2];
			}
		}
	}
	for(i=0;i<v.size();i++){
		v[i]=auxv[static_cast<int>(det[i][2])];
	}
}
